const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'db',
  user: 'root',
  password: 'password',
  database: 'inventory_db'
});

app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashed], err => {
    if (err) return res.sendStatus(500);
    res.sendStatus(201);
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err || results.length === 0) return res.sendStatus(401);
    const match = await bcrypt.compare(password, results[0].password);
    if (!match) return res.sendStatus(401);
    const token = jwt.sign({ userId: results[0].id }, 'secret');
    res.json({ token });
  });
});

app.listen(3001);